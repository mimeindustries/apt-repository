Headless Pi
===========

This is an app which enables you to easily interact with your Raspberry Pi without needing to ever plug it in to a monitor.